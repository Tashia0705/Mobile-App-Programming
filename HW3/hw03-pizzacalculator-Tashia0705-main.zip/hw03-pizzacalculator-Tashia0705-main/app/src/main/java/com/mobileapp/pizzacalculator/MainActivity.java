/*
Mobile App Development I -- COMP.4630 Honor Statement
The practice of good ethical behavior is essential for maintaining
good order in the classroom, providing an enriching learning
COMP.4630 HW 03 F23 - Dr. Lin
experience for students, and training as a practicing computing
professional upon graduation. This practice is manifested in the
University's Academic Integrity policy. Students are expected to
strictly avoid academic dishonesty and adhere to the Academic
Integrity policy as outlined in the course catalog. Violations will
be dealt with as outlined therein. All programming assignments in
this class are to be done by the student alone unless otherwise
specified. No outside help is permitted except the instructor and
approved tutors.
I certify that the work submitted with this assignment is mine and
was generated in a manner consistent with this document, the course
academic policy on the course website on Blackboard, and the UMass
Lowell academic code.
Date: 09/24/2023
Name: Tashia Boddu
*/

/***********************************************
 Author: Tashia Boddu
 Date: 09/24/2023
 Purpose: Create a pizza calculating app
 What Learned: I learned how to incorporate the techniques taught in
 class to create this app
 Sources of Help: geeksforgeeks, stackoverflow
 Time Spent: 3 hours
 Extra Points Explanation: <briefly explain what the surprise is>
 ***********************************************/

package com.mobileapp.pizzacalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* reference to the textview(num of pizzas), spinner and EditText */
        EditText num_people = findViewById(R.id.editTextText);
        Spinner how_hungry = findViewById(R.id.spinner);
        TextView pizza_out = findViewById(R.id.pizza_output);

        /* Once button is clicked.. */
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                /* get integer value of how many ppl are attending */
                int people = Integer.parseInt(String.valueOf(num_people.getText()));
                /* get the selected hunger lvl from the spinner */
                String hunger_lvl = how_hungry.getSelectedItem().toString();

                int result;
                /* use input from spinner and output num of pizzas*/
                if(hunger_lvl.equals("Light") ) {
                    result = people * 2;
                    pizza_out.setText(String.valueOf(result) +" Slices");
                }
                if(hunger_lvl.equals("Medium")) {
                    result = people * 3;
                    pizza_out.setText(String.valueOf(result) +" Slices");
                }
                if(hunger_lvl.equals("Ravenous")) {
                    result = people * 4;
                    pizza_out.setText(String.valueOf(result) +" Slices");
                } 
            }
        });
    }
}