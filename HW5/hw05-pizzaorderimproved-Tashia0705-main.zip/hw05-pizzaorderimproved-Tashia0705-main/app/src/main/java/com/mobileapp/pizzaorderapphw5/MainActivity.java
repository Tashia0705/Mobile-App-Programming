/***********************************************
 Author: Tashia Boddu
 Date: 10/15/2023
 Purpose: Improve Pizza Order App
 What Learned: Learned how to use landscape mode and also save data
 Sources of Help: geeksforgeeks, stackoverflow
 Time Spent: 3-4 hours
 Extra Points Explanation: <briefly explain what the surprise is>
 ***********************************************/

/*
COMP.4630 HW 05 F23 - Dr. Lin
Mobile App Development I -- COMP.4630 Honor Statement
The practice of good ethical behavior is essential for maintaining
good order in the classroom, providing an enriching learning
experience for students, and training as a practicing computing
professional upon graduation. This practice is manifested in the
University's Academic Integrity policy. Students are expected to
strictly avoid academic dishonesty and adhere to the Academic
Integrity policy as outlined in the course catalog. Violations will be
dealt with as outlined therein. All programming assignments in this
class are to be done by the student alone unless otherwise specified.
No outside help is permitted except the instructor and approved
tutors.
I certify that the work submitted with this assignment is mine and was
generated in a manner consistent with this document, the course
academic policy on the course website on Blackboard, and the UMass
Lowell academic code.
Date: 10/15/2023
Name: Tashia Boddu
*/

package com.mobileapp.pizzaorderapphw5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    boolean enableButtons = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* get input from editText and get R.ids*/
        TextView pizzaOutput = findViewById(R.id.textView6);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        EditText numOfPpl = findViewById(R.id.editText);
        Button button = findViewById(R.id.button);
        CheckBox checkBox1 = findViewById(R.id.checkBox1);
        CheckBox checkBox2 = findViewById(R.id.checkBox2);
        CheckBox checkBox3 = findViewById(R.id.checkBox3);

        if(savedInstanceState != null) {
            button.setEnabled(savedInstanceState.getBoolean("button"));
            numOfPpl.setEnabled(savedInstanceState.getBoolean("numOfPpl"));
            radioGroup.setEnabled(savedInstanceState.getBoolean("radioGroup"));
            checkBox1.setEnabled(savedInstanceState.getBoolean("checkBox1"));
            checkBox2.setEnabled(savedInstanceState.getBoolean("checkBox2"));
            checkBox3.setEnabled(savedInstanceState.getBoolean("checkBox3"));
            enableButtons = false;
        }

        /* listener that sees when a user inputs text into editView */
        numOfPpl.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                        /* check to see if the input is empty */
                        String str = numOfPpl.getText().toString();
                        if(str.isEmpty()) {
                            pizzaOutput.setText("0 Pizza");
                        }
                        /* if not empty calculate the # of pizzas based on which
                         button is clicked */
                        double result;
                        int people = Integer.parseInt(String.valueOf(numOfPpl.getText()));
                        if (checkedId == R.id.radioButton) {
                            result = Math.ceil(((double)people * 2)/12);
                            pizzaOutput.setText(String.valueOf(result) +" Pizzas");
                        } else if (checkedId == R.id.radioButton2) {
                            result = Math.ceil(((double)people * 3)/12);
                            pizzaOutput.setText(String.valueOf(result) +" Pizzas");
                        } else if (checkedId == R.id.radioButton3) {
                            result = Math.ceil(((double)people * 4)/12);
                            pizzaOutput.setText(String.valueOf(result) +" Pizzas");
                        }
                    }
                });
            } 
            @Override
            public void afterTextChanged(Editable s) {}
        });

        /* Display toppings based on how many are selected - Checkbox 1 */
        TextView mushrooms = findViewById(R.id.textView7);
        checkBox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    mushrooms.setText("Mushrooms");
                }
                else {
                    mushrooms.setText("");
                }
            }
        });
        /* Checkbox 2*/
        TextView chicken = findViewById(R.id.textView8);
        checkBox2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    chicken.setText("Chicken");
                }
                else {
                    chicken.setText("");
                }
            }
        });

        /* Checkbox 3 */
        TextView pepperoni = findViewById(R.id.textView9);
        checkBox3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {
                    pepperoni.setText("Pepperoni");
                }
                else {
                    pepperoni.setText("");
                }
            }
        });

        /* Submit Order button - disables checkbox + snackbar */
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Snackbar.make(button, "Your order is submitted", Snackbar.LENGTH_SHORT).show();
                checkBox1.setEnabled(false);
                checkBox2.setEnabled(false);
                checkBox3.setEnabled(false);
                numOfPpl.setEnabled(false);
                RadioButton radBut1 = findViewById(R.id.radioButton);
                radBut1.setEnabled(false);
                RadioButton radBut2 = findViewById(R.id.radioButton2);
                radBut2.setEnabled(false);
                RadioButton radBut3 = findViewById(R.id.radioButton3);
                radBut3.setEnabled(false);
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putBoolean("button", enableButtons);
        savedInstanceState.putBoolean("numOfPpl", enableButtons);
        savedInstanceState.putBoolean("radioGroup", enableButtons);
        savedInstanceState.putBoolean("checkBox1", enableButtons);
        savedInstanceState.putBoolean("checkBox2", enableButtons);
        savedInstanceState.putBoolean("checkBox3", enableButtons);
        super.onSaveInstanceState(savedInstanceState);
    }
}
