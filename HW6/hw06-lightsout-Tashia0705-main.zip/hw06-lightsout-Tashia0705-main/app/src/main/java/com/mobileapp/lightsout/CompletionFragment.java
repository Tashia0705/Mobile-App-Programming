package com.mobileapp.lightsout;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class CompletionFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_completion, container, false);

        TextView output = view.findViewById(R.id.textView7);
        output.setText("Number of Moves: " + CompletionFragmentArgs.fromBundle(requireArguments()).getNumOfMoves());
        return view;
    }
}