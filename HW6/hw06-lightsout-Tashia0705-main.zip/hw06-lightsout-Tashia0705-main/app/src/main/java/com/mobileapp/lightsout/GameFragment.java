package com.mobileapp.lightsout;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.graphics.Color;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.Random;


public class GameFragment extends Fragment {
    int numRow = 3; int numCol = 3;
    Button btnGrid[][] = new Button[numRow][numCol];
    int updatedColor;
    int allMoves;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_game, container, false);

        TableLayout tbLayout = view.findViewById(R.id.tableLayout);
        TextView numMoves = view.findViewById(R.id.allMoves);
        Button newGame = view.findViewById(R.id.newGame);

        String colorUpdate = GameFragmentArgs.fromBundle(requireArguments()).getColorUpdate();
        if(colorUpdate.equals("Green")) {
            updatedColor = Color.GREEN;
        }
        if(colorUpdate.equals("Red")) {
            updatedColor = Color.RED;
        }
        if(colorUpdate.equals("Yellow")) {
            updatedColor = Color.YELLOW;
        }
        else {
            updatedColor = Color.BLUE;
        }

        for(int i = 0; i < numRow; i++) {
            TableRow row = (TableRow) tbLayout.getChildAt(i);
            for (int j = 0; j < numCol; j++) {
                View view2 = row.getChildAt(j);
                if(view2 instanceof Button) {
                    Button button = (Button) view2;
                    if (random() == 0) {
                        button.setTag("ON");
                        button.setBackgroundColor(updatedColor);
                    }
                    else {
                        button.setBackgroundColor(Color.GRAY);
                        button.setTag("OFF");
                    }
                    button.setOnClickListener(v -> {
                        int id = v.getId();
                        allMoves++;
                        numMoves.setText("Number of Moves: " + allMoves);

                        if (id == R.id.button1) {
                            statusInverter(view.findViewById(R.id.button1));
                            statusInverter(view.findViewById(R.id.button2));
                            statusInverter(view.findViewById(R.id.button4));
                        }
                        else if (id == R.id.button2) {
                            statusInverter(view.findViewById(R.id.button1));
                            statusInverter(view.findViewById(R.id.button2));
                            statusInverter(view.findViewById(R.id.button3));
                            statusInverter(view.findViewById(R.id.button5));
                        }
                        else if (id == R.id.button3) {
                            statusInverter(view.findViewById(R.id.button3));
                            statusInverter(view.findViewById(R.id.button2));
                            statusInverter(view.findViewById(R.id.button6));
                        }
                        else if (id == R.id.button4) {
                            statusInverter(view.findViewById(R.id.button4));
                            statusInverter(view.findViewById(R.id.button1));
                            statusInverter(view.findViewById(R.id.button5));
                            statusInverter(view.findViewById(R.id.button7));

                        }
                        else if (id == R.id.button5) {
                            statusInverter(view.findViewById(R.id.button5));
                            statusInverter(view.findViewById(R.id.button2));
                            statusInverter(view.findViewById(R.id.button4));
                            statusInverter(view.findViewById(R.id.button6));
                            statusInverter(view.findViewById(R.id.button8));

                        }
                        else if (id == R.id.button6) {
                            statusInverter(view.findViewById(R.id.button6));
                            statusInverter(view.findViewById(R.id.button3));
                            statusInverter(view.findViewById(R.id.button5));
                            statusInverter(view.findViewById(R.id.button9));

                        }
                        else if (id == R.id.button7) {
                            statusInverter(view.findViewById(R.id.button7));
                            statusInverter(view.findViewById(R.id.button4));
                            statusInverter(view.findViewById(R.id.button8));

                        }
                        else if (id == R.id.button8) {
                            statusInverter(view.findViewById(R.id.button8));
                            statusInverter(view.findViewById(R.id.button5));
                            statusInverter(view.findViewById(R.id.button7));
                            statusInverter(view.findViewById(R.id.button9));

                        }
                        else if (id == R.id.button9) {
                            statusInverter(view.findViewById(R.id.button9));
                            statusInverter(view.findViewById(R.id.button6));
                            statusInverter(view.findViewById(R.id.button8));
                        }

                        if(gameComplete(view)) {
                            GameFragmentDirections.ActionGameFragmentToCompletionFragment action =
                                    GameFragmentDirections.actionGameFragmentToCompletionFragment(String.valueOf(allMoves));
                            Navigation.findNavController(view).navigate(action);
                            allMoves = 0;
                        }
                    });
                    btnGrid[i][j] = button;
                }

            }

        }
        newGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new_game();
                numMoves.setText("Number of Moves: " + allMoves);
            }
        });
        return view;
    }
    static int random() {
        return (int) (10 * Math.random()) & 1;
    }

    private void statusInverter(Button buttonView) {
        // Using tag to determine the state of each button.
        if (buttonView.getTag().toString() == "ON") {
            buttonView.setBackgroundColor(Color.GRAY);
            buttonView.setTag("OFF");
        }
        else if (buttonView.getTag().toString() == "OFF") {
            buttonView.setBackgroundColor(updatedColor);
            buttonView.setTag("ON");
        }
    }

    private void new_game() {
        allMoves = 0;
        for(int i = 0; i < numRow; i++) {
            for(int j = 0; j < numCol; j++) {
                Button button = btnGrid[i][j];
                if(random() == 0) {
                    button.setBackgroundColor(updatedColor);
                    button.setTag("ON");
                }
                else {
                    button.setBackgroundColor(Color.GRAY);
                    button.setTag("OFF");
                }

            }
        }
    }

    private boolean gameComplete(View view) {
        for (int i = 0; i < numRow; i++) {
            for (int j = 0; j < numCol; j++) {
                if (btnGrid[i][j].getTag().toString() == "ON") {
                    return false;
                }
            }
        }
        return true;
    }


}