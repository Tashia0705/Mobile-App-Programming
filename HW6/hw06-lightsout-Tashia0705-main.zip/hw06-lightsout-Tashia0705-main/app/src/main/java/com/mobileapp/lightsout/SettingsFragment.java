package com.mobileapp.lightsout;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;


public class SettingsFragment extends Fragment {
    String result;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        Spinner spinner = view.findViewById(R.id.colorSpinner);
        Button updateColor= view.findViewById(R.id.updateButton);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                result = spinner.getSelectedItem().toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        updateColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!result.isEmpty()) {
                    SettingsFragmentDirections.ActionSettingsFragmentToGameFragment
                            action = SettingsFragmentDirections.actionSettingsFragmentToGameFragment().setColorUpdate(result);
                    Navigation.findNavController(view).navigate(action);
                }
            }
        });

        return view;
    }
}